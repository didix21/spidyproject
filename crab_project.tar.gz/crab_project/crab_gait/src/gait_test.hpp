
#ifndef GAIT_TEST_HPP_
#define GAIT_TEST_HPP_

#include <ros/ros.h>
#include <kdl_parser/kdl_parser.hpp>
//#include <kdl/path_line.hpp>
#include <kdl/rotational_interpolation_sa.hpp>
//#include <kdl/path_composite.hpp>
#include <kdl/path_roundedcomposite.hpp>




#endif /* GAIT_TEST_HPP_ */
