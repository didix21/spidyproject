/*
 * Compass.h
 *
 *  Created on: 04.10.2013
 *      Author: tuuzdu
 */

#ifndef COMPASS_H_
#define COMPASS_H_

void Compass_Heading();

#endif /* COMPASS_H_ */
