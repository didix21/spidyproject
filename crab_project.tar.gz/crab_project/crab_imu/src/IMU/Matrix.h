/*
 * Matrix.h
 *
 *  Created on: 04.10.2013
 *      Author: tuuzdu
 */

#ifndef MATRIX_H_
#define MATRIX_H_

void Matrix_Multiply(float a[3][3], float b[3][3], float mat[3][3]);

#endif /* MATRIX_H_ */
